import React from "react";
import { useParams, Outlet } from "react-router";

const BaseInbox = props => {

  let { userId } = useParams();

  return (
    <>
      <h2>Inbox page</h2>
      <Messages id={userId} />
      <Outlet />
    </>
  );
};

export const Messages = (props) => {
  return <h3>Messages for user: {props.id} </h3>;
};

export const Stats = () => {
  return <h3>Statistical data</h3>;
};

export const Draft = () => {
  return <h3>Draft emails</h3>;
};

export default BaseInbox;
