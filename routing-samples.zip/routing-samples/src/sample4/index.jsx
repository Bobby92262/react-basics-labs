import React from "react";
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Route, Routes, Navigate, Link } from "react-router";
import { About } from "../sample1";
import Inbox, { Stats, Draft } from "./inbox";

const Home = () => {
  return (
    <>
      <h2>Home page</h2>
      <h3>Nested route demo</h3>
        <p>
          Try <Link to='/inbox/1234'> this link</Link>
          <span> for basic inbox page.</span>
        </p>
        <p>
          Try <Link to='/inbox/1234/statistics'> this link</Link>
          <span> for page with inbox and email statistics.</span>
        </p>
        <p>
          Try <Link to='/inbox/1234/drafts'> this link </Link>
          <span> for page with inbox and draft emails.</span>
        </p>
    </>
  );
};

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/about" element={ <About /> } />
        <Route path="/inbox/:userId" element={ <Inbox /> } >
          <Route path="/inbox/:userId/statistics" element = { <Stats /> } />
          <Route path="/inbox/:userId/drafts" element = { <Draft /> } />
        </Route>
        <Route path="/" element={ <Home /> } />
        <Route path="*" element={ <Navigate to="/" /> } />
      </Routes>
    </BrowserRouter>
  );
};

createRoot(document.getElementById('root')).render(<App />);