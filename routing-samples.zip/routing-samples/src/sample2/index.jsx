import React from "react";
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Route, Routes, Navigate, Link } from "react-router";
import { About, Inbox } from "../sample1";

const Home = () => {
  return (
    <>
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/about">About</Link>
        </li>
        <li>
          <Link to="/inbox">Inbox</Link>
        </li>
      </ul>
      <h1>Home page</h1>
    </>
  );
};

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/about" element={ <About /> } />
        <Route path="/inbox" element={ <Inbox /> } />
        <Route path="/" element={ <Home /> } />
        <Route path="*" element={ <Navigate to="/" /> } />
      </Routes>
    </BrowserRouter>
  );
};

createRoot(document.getElementById('root')).render(<App />);
