import React from "react";
import { useParams, useNavigate, Link } from "react-router";

const BaseInbox = props => {

  let { userId } = useParams();
  
  const navigate = useNavigate();
  console.log(navigate);

  const goBack = () => {
    navigate(-1);
  }

    return (
      <>
        <h2>Inbox page</h2>
        <h3>Messages for user: {userId} </h3>

        <Link onClick={() => goBack()}>Back</Link>

      </>
    );
};

export default BaseInbox;
