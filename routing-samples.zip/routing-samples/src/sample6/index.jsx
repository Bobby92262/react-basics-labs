import React from "react";
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Route, Routes, Navigate, Link, useNavigate } from "react-router";
import { About } from "../sample1";
import { Stats, Draft } from "../sample4/inbox";
import Inbox from "./inbox";

const Home = () => {

  const navigate = useNavigate();

  const goForward = () => {
    navigate(+1);
  }

  const goToPage = (pageURL) => {
    navigate(pageURL);
  }

  return (
    <>
      <ul>
        <li>
          <Link to="/about">About</Link>
        </li>
        <li>
          <Link to="/inbox/1234">Inbox</Link>  
        </li>
      </ul>
      <h1>Home page</h1>
      <h3>useNavigate demos</h3>

      <Link onClick={() => goForward()}>Forward (to the last page visited)</Link>
      <br /><br />
      <button onClick={() => goToPage("/about")}>Go to About page (with navigate)</button>

    </>
  );
};

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/about" element={ <About /> } />
        <Route path="/inbox/:userId" element={ <Inbox /> } >
          <Route path="/inbox/:userId/statistics" element = { <Stats /> } />
          <Route path="/inbox/:userId/drafts" element = { <Draft /> } />
        </Route>
        <Route path="/" element={ <Home /> } />
        <Route path="*" element={ <Navigate to="/" /> } />
      </Routes>
    </BrowserRouter>
  );
};

createRoot(document.getElementById('root')).render(<App />);

