import React from "react";
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Route, Routes, Navigate } from "react-router";

export const About = () => {
  return <h2>About page</h2>;
};

export const Inbox = () => {
  return <h2>Inbox page</h2>;
};

const Home = () => {
  return <h1>Home page</h1>;
};

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/about" element={ <About /> } />
        <Route path="/inbox" element={ <Inbox /> } />
        <Route path="/" element={ <Home /> } />
        <Route path="*" element={ <Navigate to="/" /> } />
      </Routes>
    </BrowserRouter>
  );
};

createRoot(document.getElementById('root')).render(<App />);
