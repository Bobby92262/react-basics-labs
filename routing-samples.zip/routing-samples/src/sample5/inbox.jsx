import React from "react";
import { useParams, useLocation } from "react-router";

const BaseInbox = props => {

  let { userId } = useParams();
  
  let location = useLocation();
  console.log(location);

  const { beta, test } = location.state;
 
    return (
      <>
        <h2>Inbox page</h2>
        <h3>Messages for user: {userId} </h3>
        <h3>Welcome, {location.state.name}</h3>
        <p>{`Link Props: Beta - ${beta}, Message - ${test}`}</p>

      </>
    );
};

export default BaseInbox;
