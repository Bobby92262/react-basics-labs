import React from "react";
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Route, Routes, Navigate, Link } from "react-router";
import { About } from "../sample1";
import { Stats, Draft } from "../sample4/inbox";
import Inbox from "./inbox";

const Home = () => {

  return (
    <>
      <ul>
        <li>
          <Link to="/about">About</Link>
        </li>
        <li>
          <Link
            to="/inbox/1234"
            state={{
              name: "U.N. Own",
              beta: true,
              test: "Hello"
            }}
          >
            Inbox<span> (Link with extra props)</span>
          </Link>    
        </li>
      </ul>
      <h1>Home page</h1>
      <h3>Demos passing additional props with a Link</h3>
    </>
  );
};

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/about" element={ <About /> } />
        <Route path="/inbox/:userId" element={ <Inbox /> } >
          <Route path="/inbox/:userId/statistics" element = { <Stats /> } />
          <Route path="/inbox/:userId/drafts" element = { <Draft /> } />
        </Route>
        <Route path="/" element={ <Home /> } />
        <Route path="*" element={ <Navigate to="/" /> } />
      </Routes>
    </BrowserRouter>
  );
};

createRoot(document.getElementById('root')).render(<App />);